#!/bin/sh

# Print first message on screen.
exec /sbin/init

