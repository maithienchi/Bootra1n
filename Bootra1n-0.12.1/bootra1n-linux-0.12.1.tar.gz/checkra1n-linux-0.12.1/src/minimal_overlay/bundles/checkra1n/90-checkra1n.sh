#!/bin/sh

# Launch checkra1n CLI
checkra1n
